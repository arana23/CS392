//I pledge my honor that I have abided by the Stevens Honor System. -Aparajita Rana

#include "cs392_log.h"

void cs392_socket_log(int one, int two){
	FILE *fp;
	fp = fopen("cs392_socket.log", "a");
	if (fp == NULL) {
    	printf("Cannot open file");
  }
	fprintf(fp, "%d %d\r\n", one, two);
	fflush(fp);
	fclose(fp);
}