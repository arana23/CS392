//I pledge my honor that I have abided by the Stevens Honor System - Aparajita Rana
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <errno.h>
#include <netinet/in.h>
#include <arpa/inet.h>

void cs392_socket_log(int one, int two);