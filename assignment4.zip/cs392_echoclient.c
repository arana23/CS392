//I pledge my honor that I have abided by the Stevens Honor System. -Aparajita Rana

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

int main(int argc, char ** argv){
	//one argument, which is the port number you want the server to use
	//error checking
	if (argc != 3) {
	 	perror("Usage: Invalid arguments");
	 	exit(EXIT_FAILURE);
	}

	int clientsock;
	int BUFFSIZE=1024;
	struct sockaddr_in echoserver;
	char buffer[BUFFSIZE];
	char input[BUFFSIZE];
	unsigned int echolen;
	//It will need to create a socket that uses the IPv4 domain and the SOCK_STREAM type (protocol can be 0)
	clientsock = socket(AF_INET, SOCK_STREAM, 0);

	//It will need to bind an address to the above socket. As explained above, the port number is provided by the first argument to the main function. 
	//error checking
	if(clientsock == 0) {
		perror("Socket Error");
		exit(EXIT_FAILURE);
	}
	
	memset(&echoserver, 0, sizeof(echoserver)); /* Clear struct */
	echoserver.sin_family = AF_INET; /* Internet/IP */
	echoserver.sin_addr.s_addr = inet_addr(argv[1]); /* IP address */
	echoserver.sin_port = htons(atoi(argv[2])); /* server port */

	//check if can connect
	if ((connect(clientsock, (struct sockaddr *) &echoserver, sizeof(echoserver))) != 0) {
		printf("Connection Error\n");
		exit(EXIT_FAILURE);
	}
	//asks user to enter message
	printf("Enter Message: ");
	fgets(input, sizeof(input), stdin);
	echolen=strlen(input);

	//send, recieve, print, and close
	send(clientsock, input, echolen, 0);
	recv(clientsock, buffer, BUFFSIZE-1, 0);

	printf("%s\n", buffer);
	close(clientsock);
	exit(1);
	return 0;
}
