//I pledge my honor that I have abided by the Stevens Honor System. -Aparajita Rana

#include "cs392_log.h"
#include <stdio.h>

int main(int argc, char ** argv){
	//one argument, which is the port number you want the server to use
	//error checking
	if (argc != 2) {
	 	perror("Usage: Invalid argument");
	 	exit(EXIT_FAILURE);
	}

	int serversock; 
	int clientsock;
	int BUFFSIZE = 1024;
	struct sockaddr_in echoserver, echoclient;
	char buffer[BUFFSIZE];
	//It will need to create a socket that uses the IPv4 domain and the SOCK_STREAM type (protocol can be 0)
	serversock = socket(AF_INET, SOCK_STREAM, 0);

	//It will need to bind an address to the above socket. As explained above, the port number is provided by the first argument to the main function. 
	//error checking
	if(serversock < 0) {
		perror("Socket Error");
		exit(EXIT_FAILURE);
	}

	memset(&echoserver, 0, sizeof(echoserver)); /* Clear struct */
	echoserver.sin_family = AF_INET; /* Internet/IP */
	echoserver.sin_addr.s_addr = htonl(INADDR_ANY); /* IP address */
	int temp=atoi(argv[1]); 
	echoserver.sin_port = htons(temp); /* server port */

	//It needs to listen to the socket after binding the address. Please restrict that at most 5 clients can be pending to connect to this server.
	if(bind(serversock, (struct sockaddr *) &echoserver, sizeof(echoserver))!=0){
		perror("Bind Error");
		exit(EXIT_FAILURE);
	}

	//bc max is 5
	if(listen(serversock, 5)!=0){
		perror("Listen Error");
		exit(EXIT_FAILURE);
	}
	
	while(1){
		int len = sizeof(echoclient);
		clientsock = accept(serversock, (struct sockaddr *) &echoclient, &len);
		if(clientsock<0){
			perror("Client Sock Error");
			exit(EXIT_FAILURE);
		}
		//do the actual logging 
		cs392_socket_log(echoclient.sin_addr.s_addr, echoclient.sin_port);
		//clear buffer basically through memset
		memset(&buffer, '\0', sizeof(buffer));

		//recieve, send, and close client
		recv(clientsock, buffer, BUFFSIZE, 0);
		send(clientsock, buffer, BUFFSIZE, 0);
		close(clientsock);
	}
	close(clientsock);
	exit(1);
	return 0;
}
