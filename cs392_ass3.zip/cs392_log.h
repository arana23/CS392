// I pledge my honor that I have abided by the Stevens Honor System. - Aparajita Rana

//The “cs392_log.h” should provide a prototype for that function.

#ifndef cs392_log_h
#define cs392_log_h

#include <stdio.h>

void log_commands(char *);

#endif