//I pledge my honor that I have abided by the Stevens Honor System. - Aparajita Rana

#ifndef cs_392_exec_h
#define cs_392_exec_h

#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <errno.h>
#include <stdbool.h>

static void cleanup(char**);
void split_word(char* str);
void exec(char *);
void handle_pipe(int[]);

#endif