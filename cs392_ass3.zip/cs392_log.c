// I pledge my honor that I have abided by the Stevens Honor System. - Aparajita Rana

/*If “cs392_shell.log” does not exist, this function should create that file in the current working directory. 
The “cs392_log.h” should provide a prototype for that function.*/
#include "cs392_log.h"
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

//define a function which logs each command (and the options) to “cs392_shell.log” in an appending mode
void log_commands(char * commands) {
	//appending mode -> "a"
	FILE *file;
	file = fopen("cs392_shell.log", "a");

	if (file == NULL) {
		/*// create that file in the current working directory
		$temp = getcwd();
		chdir(file);
		chdir($temp);*/
		perror("Error - File is Null\n");
	}
	else {
		//log commands
		fprintf(file, "%s\n", commands);
	}
	fclose(file);
}