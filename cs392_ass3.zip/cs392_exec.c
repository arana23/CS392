// I pledge my honor that I have abided by the Stevens Honor System. - Aparajita Rana

// define a function which forks one/multiple child process(es) to run the command (or commands concatenated via pipe) from the user
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <signal.h>
#include "cs392_exec.h"

//global so it could be used in other functions
bool has_pipe;
char** words;
char** pipes;
int word_count;

//help cleaning and clearing -> repetative function
void cleanup(char** words){
	for(int x=0;x<word_count;x++){
		free(words[x]);
	}
	free(words);
}
//deal with pipe case
void handle_pipe(int pfd[]){
	int pid=fork();
	if(pid<0){
		printf("Error");
	}
	//child process
	if(pid==0){
		dup2(pfd[1], 1);
		close(pfd[0]);
		execvp(words[0], words);
		perror(pipes[0]);
		//second portion
		dup2(pfd[0], 0);
		close(pfd[1]);
		execvp(pipes[0], pipes);
		perror(pipes[0]);
	}
}

void split_word(char* in){
	has_pipe=false;
	word_count=1;
	int x;

	for(x=0; in[x]!='\0';x++){
		//words
		if(in[x]==' '){
			++word_count;
		}
		//pipe
		if(in[x]=='|'){
			has_pipe=true;
		}
	}
	//general starting place
	words=malloc(256*sizeof(char*));
	pipes=malloc(256*sizeof(char*));

	//space for words
	for(x=0; x<word_count;x++){
		words[x]=malloc(sizeof(char)*word_count);
	}
	//if there is a pipe -> designate space
	if(has_pipe){
		for(x=0; x<word_count;x++){
			pipes[x]=malloc(sizeof(char)*word_count);
		}
	}

	//given the case there are NOT any pipes
	if(has_pipe==false){
		char* temp=strtok(in," ");
		for(x=0;temp!=NULL;x++)
		{
			strcpy(words[x],temp);
			temp=strtok(NULL," ");
		}
		words[x]=NULL;
	}
	//there is a pipe
	else{
		//store the pipe part
		char* temp=strtok(in,"|");
		char*arr[2];
		for(x=0;temp!=NULL;x++)
		{
			arr[x]=temp;
			temp=strtok(NULL,"|");
		}

		char* temp2=strtok(arr[0]," ");
		for(x=0;temp2!=NULL;x++)
		{
			strcpy(words[x],temp2);
			temp2=strtok(NULL,"|");
		}
		words[x]=NULL;

		//dealing with second part of pipe
		int size=strlen(words[1]);
		for(x=0;x<size;x++){
			words[1][x]=words[1][x+1];
		}

		char* sec=strtok(words[1]," ");
		for(x=0;sec!=NULL;x++)
		{
			strcpy(words[x],sec);
			sec=strtok(NULL," ");
		}
		pipes[x]=NULL;

	}
	//return words;
}

void exec(char* in){
	//apply above function -> seperate words
	split_word(in);
	char** vals=words;
	int pid;
	//user quits -> cleanup and leave
	if(strcmp(vals[0],"exit")==0){
		printf("Exit\n");
		cleanup(vals);
		exit(0);
	}
	else{
		if(has_pipe==false){
			pid=fork();
			//error: less than 1
			if(pid<0){
				printf("Fork Error\n");
				cleanup(vals);
				exit(1);
			}
			//greater than/equal to 1: parent process
			else if(pid>0){
				wait(NULL);
			}
			//child proc 
			else{
				int temp;
				temp=execvp(vals[0],vals);

				// less than zero -> wrong command
				if(temp<0)
					{
					printf("not a valid command\n");
					cleanup(vals);
					exit(1);
					}
			}
		}
		/*	causing too many further issues -> commented out bc this way at least cs392_shell $ gets printed out
		//has a pipe
		else{
			int pid, status;
			int fd[2];
			pipe(fd);
			handle_pipe(fd);
		}*/
		
	}
	cleanup(vals);

}
