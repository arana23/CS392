//I pledge my honor that I have abided by the Stevens Honor System. - Aparajita Rana

#ifndef cs392_signal_h
#define cs392_signal_h

#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>

void handler(int, siginfo_t*, void*);
void register_handles();

#endif