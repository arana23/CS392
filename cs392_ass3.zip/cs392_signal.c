// I pledge my honor that I have abided by the Stevens Honor System. - Aparajita Rana
#include "cs392_signal.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

//define handlers for the SIGINT and SIGTSTP signals and define a function to register those handlers

//define handlers for SIGINT and SIGTSTP, we need 3 parameters bc of sigaction interface struct
void handler(int val, siginfo_t *stuff, void *sig) {
	//termination -> ctrl+c
	if (val == SIGINT) {
		printf("Termination Signal received, Signal: %d\n",val);
	}
	//stop -> ctrl+z
	if (val == SIGTSTP) {
		printf("Stop Signal received, Signal: %d\n",val);
	}
}

//define function to register those handlers
void register_handles() {
	struct sigaction hnd;
	memset(&hnd, '\0', sizeof(hnd));

	//You need to use the “sigaction” interface to set up the handlers.
	hnd.sa_sigaction = &handler;
	hnd.sa_flags = SA_SIGINFO;
	
	//error checking
	if(sigaction(SIGTSTP, &hnd, NULL) < 0){
		perror("SIGTSTP Error!\n");
	}
	if (sigaction(SIGINT, &hnd, NULL) < 0){
		perror("SIGINT Error!\n");
	}
}

