// I pledge my honor that I have abided by the Stevens Honor System. - Aparajita Rana

// It will include “cs392_exec.h”, “cs392_log.h”, and “cs392_signal.h” for prototypes of the above mentioned functions.
#include "cs392_exec.h"
#include "cs392_log.h"
#include "cs392_signal.h"
#include <stdlib.h>

/*It will use functions from “cs392_exec.c” to run each command from user
It will use functions from “cs392_log.c” to do the logging 
It will use functions from “cs392_signal.c” to register signal handler
*/
int main(){
	//default -> max amt characters
	char temp[256];
	int input;
	while(1)
	{
		//signal function
		register_handles();

		//print out the default statement 
		printf("cs392_shell $: ");

		//clean output buffer and move data to console -> stdout
		fflush(stdout);

		//take in vals
		input = read(0,temp, 255);

		//error checking 
		if(input<0) {
			
			//if it's a signal -> continue it is not an error
			if (errno==EINTR) 
			{
				continue;
			} 
			//this is an error
			else 
			{
				printf("Error\n");
				exit(1);
			}
	}
		//close up
		temp[input-1] = '\0';
		//log function usage
		log_commands(temp);
		//exec function usage
		exec(temp);
	}
	return 0;
}
